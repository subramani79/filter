# Filter-Project
A small JavaScript project that wires up two filters for a fictitious website. Filter buttons to show only filtered items and a filter search bar to show only filtered item.
